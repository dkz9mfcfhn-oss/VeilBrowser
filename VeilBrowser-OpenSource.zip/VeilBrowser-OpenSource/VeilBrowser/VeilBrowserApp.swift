// SPDX-License-Identifier: GPL-3.0-only
import SwiftUI
import WebKit
import CryptoKit
import Security

@main
struct VeilBrowserApp: App {
    var body: some Scene { WindowGroup { BrowserView() } }
}

@MainActor
final class Browser: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    @Published var webView: WKWebView?
    @Published var address = ""
    @Published var loading = false
    @Published var progress = 0.0
    @Published var error: String?
    @Published var isHome = true
    @Published var ready = false
    @Published var videoInfo = "打开视频后可查看缓冲状态"
    let filtering = AdFilterController()
    override init() {
        super.init()
        filtering.onChange = { [weak self] in
            guard let self, let controller = self.webView?.configuration.userContentController else { return }
            controller.removeAllContentRuleLists()
            if let rules = self.rules { controller.add(rules) }
            if let enhanced = self.filtering.compiled { controller.add(enhanced) }
        }
        // Delete subscription secrets saved by earlier versions on upgrade.
        SecItemDelete([kSecClass: kSecClassGenericPassword,
                       kSecAttrService: "com.local.VeilBrowser.proxy",
                       kSecAttrAccount: "subscription"] as CFDictionary)
    }
    private var observations: [NSKeyValueObservation] = []
    private var generation = 0
    private var rules: WKContentRuleList?

    private var isPreparingFilter = false
    // Reuse only a cache compiled from exactly the current rule content.
    static let filterIdentifier: String = {
        let digest = SHA256.hash(data: Data(blockRules.utf8))
            .map { String(format: "%02x", $0) }.joined()
        return "VeilBlocker-" + digest
    }()

    func prepareFilter() {
        guard !ready, !isPreparingFilter else { return }
        isPreparingFilter = true
        error = nil
        Task { @MainActor in
            do {
                try await filtering.prepare()
                isPreparingFilter = false
                prepareLocalFilter()
            } catch {
                isPreparingFilter = false
                self.error = "增强过滤规则准备失败：\(error.localizedDescription)"
            }
        }
    }

    private func prepareLocalFilter() {
        guard !ready, !isPreparingFilter else { return }
        isPreparingFilter = true
        error = nil
        let started = ProcessInfo.processInfo.systemUptime
        let store = WKContentRuleListStore.default()!
        store.lookUpContentRuleList(forIdentifier: Self.filterIdentifier) { [weak self] list, _ in
            Task { @MainActor in
                guard let self else { return }
                if let list {
                    self.finishPreparingFilter(list, error: nil, source: "cache", started: started)
                    return
                }
                // Missing or incompatible caches are rebuilt without disabling protection.
                store.compileContentRuleList(forIdentifier: Self.filterIdentifier, encodedContentRuleList: Self.blockRules) { [weak self] list, error in
                    Task { @MainActor in
                        self?.finishPreparingFilter(list, error: error, source: "compile", started: started)
                    }
                }
            }
        }
    }

    private func finishPreparingFilter(_ list: WKContentRuleList?, error: Error?, source: String, started: TimeInterval) {
        isPreparingFilter = false
        guard let list else {
            self.error = "广告过滤器加载失败：\(error?.localizedDescription ?? "未知错误")"
            return
        }
        rules = list
        ready = true
        #if DEBUG
        let elapsed = (ProcessInfo.processInfo.systemUptime - started) * 1000
        print("[Startup] filter=\(source), ready=\(Int(elapsed))ms, webViewCreated=\(webView != nil)")
        #endif
    }

    func newSession() {
        generation += 1
        webView?.stopLoading()
        webView?.navigationDelegate = nil
        webView?.uiDelegate = nil
        observations.removeAll()
        webView = nil
        address = ""
        error = nil
        isHome = true
        progress = 0
        loading = false
        videoInfo = "打开视频后可查看缓冲状态"
        if !ready { prepareFilter() }
    }

    private func ensureWebView() -> WKWebView? {
        if let webView { return webView }
        // The first network request must always have a compiled blocker attached.
        guard let rules else { return nil }
        let started = ProcessInfo.processInfo.systemUptime
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        configuration.allowsInlineMediaPlayback = true
        configuration.allowsPictureInPictureMediaPlayback = true
        configuration.allowsAirPlayForMediaPlayback = false
        configuration.mediaTypesRequiringUserActionForPlayback = .all
        configuration.userContentController.add(rules)
        filtering.attach(to: configuration.userContentController)
        configuration.userContentController.addUserScript(WKUserScript(source: Self.adStyleScript, injectionTime: .atDocumentStart, forMainFrameOnly: false, in: .defaultClient))
        configuration.userContentController.addUserScript(WKUserScript(source: Self.adCleanupScript, injectionTime: .atDocumentStart, forMainFrameOnly: false, in: .defaultClient))
        configuration.userContentController.addUserScript(WKUserScript(source: Self.videoScript, injectionTime: .atDocumentEnd, forMainFrameOnly: false))
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = self
        view.uiDelegate = self
        view.allowsBackForwardNavigationGestures = true
        view.isInspectable = false
        observations = [
            view.observe(\.estimatedProgress, options: [.new]) { [weak self] view, _ in
                Task { @MainActor in self?.progress = view.estimatedProgress }
            },
            view.observe(\.isLoading, options: [.new]) { [weak self] view, _ in
                Task { @MainActor in self?.loading = view.isLoading }
            }
        ]
        webView = view
        #if DEBUG
        let elapsed = (ProcessInfo.processInfo.systemUptime - started) * 1000
        print("[Startup] webView created on first navigation in \(Int(elapsed))ms")
        #endif
        return view
    }

    static func destination(_ input: String) -> URL? {
        let value = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }
        if let url = URL(string: value), ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil { return url }
        if !value.contains(where: { $0.isWhitespace }), value.contains("."), let url = URL(string: "https://" + value), url.host != nil { return url }
        var components = URLComponents(string: "https://yandex.tm/search/")!
        components.queryItems = [URLQueryItem(name: "text", value: value)]
        return components.url
    }

    func open() {
        guard ready, let url = Self.destination(address), let view = ensureWebView() else { return }
        error = nil
        isHome = false
        view.load(URLRequest(url: url))
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { address = webView.url?.absoluteString ?? address }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { report(error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { report(error) }
    private func report(_ error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { self.error = error.localizedDescription }
    }
    static func isAdDestination(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        if adDomains.contains(where: { host == $0 || host.hasSuffix("." + $0) }) { return true }
        // Some sites send ads through their own signed redirect endpoint.
        // Inspect only the explicit ad marker, never the destination content.
        guard url.path == "/traffic/go",
              let token = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "t" })?.value else { return false }
        var base64 = token.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        base64 += String(repeating: "=", count: (4 - base64.count % 4) % 4)
        guard let data = Data(base64Encoded: base64),
              let payload = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return false }
        return payload["kind"] as? String == "ad"
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url,
              ["https", "http", "about", "blob"].contains(url.scheme?.lowercased() ?? ""),
              !Self.isAdDestination(url) else {
            decisionHandler(.cancel)
            return
        }
        // Keep user-activated links usable; reject script-created windows.
        if navigationAction.targetFrame == nil && navigationAction.navigationType != .linkActivated {
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard navigationAction.targetFrame == nil,
              navigationAction.navigationType == .linkActivated,
              let url = navigationAction.request.url,
              ["https", "http"].contains(url.scheme?.lowercased() ?? ""),
              !Self.isAdDestination(url) else { return nil }
        // Normal target=_blank links open in this private browsing context.
        webView.load(navigationAction.request)
        return nil
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) { completionHandler() }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) { completionHandler(false) }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) { completionHandler(nil) }
    func video(_ action: String) {
        let token = generation
        webView?.evaluateJavaScript("window.veilVideoAction && window.veilVideoAction('\(action)')") { [weak self] result, _ in
            Task { @MainActor in
                guard let self, self.generation == token else { return }
                self.videoInfo = result as? String ?? "当前页面未检测到可控制的视频；可使用网页播放器"
            }
        }
    }

    static let adDomains = [
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adsystem.com", "adnxs.com", "adsrvr.org",
        "scorecardresearch.com", "mc.yandex.ru", "an.yandex.ru", "ads.yandex.ru",
        "popads.net", "popcash.net", "adsterra.com", "propellerads.com"
    ]

    // Only explicit advertising markers are hidden. Generic dialogs, fixed
    // navigation and video players must remain visible.
    // Verified floating-ad signature: generated H5 wrapper + labeled ad frame.
    // A generic .swiper-container or iframe rule would also hide legitimate players.
    static let floatingAdSelector = "[id^='swipercontainer']:has(iframe[id^='iframeid']):has([id^='alabelbox'])"

    static let adSelectors = [
        floatingAdSelector,
        ".yandex-ad", ".ya-partner", "[id^='yandex_rtb']",
        "[id^='google_ads_iframe']", "ins.adsbygoogle", ".AdUnit", ".serp-adv__item",
        ".ad-popup", "#ad-popup", ".ads-popup", "#ads-popup",
        ".ad-overlay", "#ad-overlay", ".advert-overlay",
        ".floating-ad", "#floating-ad", ".float-ad", "#float-ad",
        "[data-ad-slot]", "[data-ad-client]", "[data-advertisement]",
        ".bottom-ad", "#bottom-ad", ".bottom-ads", "#bottom-ads", ".ad-banner", ".ads-banner",
        "[id^='ad_float']", "[id^='ad_bottom']",
        ".sticky-ad", "#sticky-ad", ".ad-sticky", ".advertisement-popup",
        "[data-ad-format='interstitial']", "[data-ad-format='anchor']",
        "[data-ad-format='sticky']", "[data-ad-format='floating']"
    ]

    // WebKit URL filters support a limited regex grammar: emit one rule per domain.
    static let blockRules: String = {
        var rules: [[String: Any]] = adDomains.map { domain in
            let escaped = domain.replacingOccurrences(of: ".", with: #"\."#)
            return [
                "trigger": ["url-filter": #"^https?://([a-z0-9-]+\.)*"# + escaped + "[:/]"],
                "action": ["type": "block"]
            ]
        }
        rules.append([
            "trigger": ["url-filter": ".*"],
            "action": [
                "type": "css-display-none",
                "selector": adSelectors.joined(separator: ", ")
            ]
        ])
        // Verified against the reported page: its banners use first-party ad redirects.
        rules.append([
            "trigger": ["url-filter": #"^https?://([a-z0-9-]+\.)*nanith\.com/traffic/go[?]"#],
            "action": ["type": "block"]
        ])
        rules.append([
            "trigger": ["url-filter": ".*", "if-domain": ["*nanith.com"]],
            "action": ["type": "css-display-none", "selector": "a[href*='/traffic/go?'], li:has(> a[href*='/traffic/go?'])"]
        ])
        // This structure contains only JSON-compatible strings, arrays and dictionaries.
        let data = try! JSONSerialization.data(withJSONObject: rules, options: [.sortedKeys])
        return String(decoding: data, as: UTF8.self)
    }()

    static var adSelectorLiteral: String {
        String(decoding: try! JSONSerialization.data(withJSONObject: adSelectors.joined(separator: ", "), options: [.fragmentsAllowed]), as: UTF8.self)
    }

    static let adStyleScript: String = {
        let css = adSelectors.joined(separator: ", ") + "{display:none!important;pointer-events:none!important}"
        let data = try! JSONSerialization.data(withJSONObject: css, options: [.fragmentsAllowed])
        let literal = String(decoding: data, as: UTF8.self)
        return """
        (() => {
          const style = document.createElement('style');
          const css = \(literal);
          const ensureStyle = () => {
            if (style.textContent !== css) style.textContent = css;
            if (document.documentElement && !style.isConnected) document.documentElement.append(style);
          };
          ensureStyle();
          new MutationObserver(ensureStyle).observe(document, {childList:true, characterData:true, subtree:true});
        })();
        """
    }()

    static let adCleanupScript = #"""
    (() => {
      // Run in WebKit's isolated content world so page scripts cannot replace this logic.
      const isAdLink = a => {
        try {
          const u = new URL(a.getAttribute('href'), document.baseURI);
          if (u.pathname !== '/traffic/go') return false;
          let token = (u.searchParams.get('t') || '').replace(/-/g, '+').replace(/_/g, '/');
          token += '='.repeat((4 - token.length % 4) % 4);
          return JSON.parse(atob(token)).kind === 'ad';
        } catch { return false; }
      };
      const hiddenElements = new WeakSet();
      const promotionCandidates = new WeakSet();
      const hide = e => {
        hiddenElements.add(e);
        if (e.style.getPropertyValue('display') !== 'none' || e.style.getPropertyPriority('display') !== 'important')
          e.style.setProperty('display', 'none', 'important');
        if (e.style.getPropertyValue('pointer-events') !== 'none' || e.style.getPropertyPriority('pointer-events') !== 'important')
          e.style.setProperty('pointer-events', 'none', 'important');
      };
      // App-install promotions are often unlabelled and use randomized class names.
      // Require the explicit promotion phrase AND a small bottom-positioned wrapper.
      const hideBottomPromotions = () => {
        if (!document.body) return;
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let node;
        while ((node = walker.nextNode())) {
          const text = (node.nodeValue || '').trim();
          if (text.length > 180 || !/防失[联聯]/.test(text)) continue;
          if (node.parentElement?.closest('script,style,noscript,textarea,select')) continue;
          let e = node.parentElement;
          for (let depth = 0; e && e !== document.body && depth < 7; depth++, e = e.parentElement) {
            promotionCandidates.add(e);
            if (e.querySelector('video,audio,form,input,textarea,[contenteditable="true"]')) break;
            const style = getComputedStyle(e), rect = e.getBoundingClientRect();
            if (!['fixed','sticky'].includes(style.position)) continue;
            if (rect.width < innerWidth * 0.25 || rect.height > innerHeight * 0.45) continue;
            const bottom = parseFloat(style.bottom);
            if (!(rect.top >= innerHeight * 0.5 || (Number.isFinite(bottom) && bottom >= 0 && bottom <= 100))) continue;
            hide(e);
            break;
          }
        }
      };
      const scan = () => {
        hideBottomPromotions();
        for (const card of document.querySelectorAll(\#(adSelectorLiteral))) hide(card);
        for (const a of document.querySelectorAll('a[href*="/traffic/go?"]')) {
          if (!isAdLink(a)) continue;
          hide(a);
          const li = a.closest('li');
          if (li && !li.querySelector('video, audio, form, input, button') &&
              [...li.querySelectorAll('a[href]')].every(isAdLink)) hide(li);
          // Remove a containing floating card only when all its links are explicit ads.
          let parent = a.parentElement;
          for (let depth = 0; parent && parent !== document.body && depth < 4; depth++, parent = parent.parentElement) {
            const style = getComputedStyle(parent);
            if (!['fixed', 'sticky', 'absolute'].includes(style.position)) continue;
            const links = [...parent.querySelectorAll('a[href]')];
            if (links.length && links.every(isAdLink) && !parent.querySelector('video, audio, form, input')) hide(parent);
          }
        }
      };
      let pending = false;
      const schedule = () => {
        if (pending) return;
        pending = true;
        requestAnimationFrame(() => { pending = false; scan(); });
      };
      scan();
      new MutationObserver(records => {
        if (records.some(r => r.type === 'childList' || r.attributeName !== 'style' || hiddenElements.has(r.target) || promotionCandidates.has(r.target))) schedule();
      }).observe(document, {
        childList: true, characterData: true, subtree: true, attributes: true, attributeFilter: ['href', 'id', 'class', 'style', 'data-ad-slot', 'data-ad-client', 'data-advertisement', 'data-ad-format']
      });
      addEventListener('resize', schedule, {passive:true});
    })();
    """#

    static let videoScript = """
    (() => {
      const setup = v => {
        if (v.dataset.veilReady) return;
        v.dataset.veilReady = '1';
        v.setAttribute('playsinline', '');
        v.addEventListener('play', () => { v.preload = 'auto'; }, {passive:true});
      };
      const scan = () => document.querySelectorAll('video').forEach(setup);
      scan();
      let pending = false;
      new MutationObserver(() => {
        if (pending) return;
        pending = true;
        requestAnimationFrame(() => { pending = false; scan(); });
      }).observe(document.documentElement, {childList:true, subtree:true});
      window.veilVideoAction = action => {
        const videos = [...document.querySelectorAll('video')];
        const v = videos.find(v => !v.paused) || videos.find(v => v.getBoundingClientRect().width > 0);
        if (!v) return '未检测到视频；跨域视频请使用网页内的播放器控制';
        if (action === 'buffer') { v.preload = 'auto'; }
        if (action === 'speed') { const rates = [1,1.25,1.5,2]; v.playbackRate = rates[(rates.indexOf(v.playbackRate)+1)%rates.length]; }
        if (action === 'pip') {
          if (v.webkitSupportsPresentationMode && v.webkitSupportsPresentationMode('picture-in-picture')) v.webkitSetPresentationMode('picture-in-picture');
          else return '此视频暂不支持画中画，请使用播放器全屏按钮';
        }
        let seconds = 0;
        for (let i=0; i<v.buffered.length; i++) if (v.buffered.start(i)<=v.currentTime && v.buffered.end(i)>=v.currentTime) seconds = v.buffered.end(i)-v.currentTime;
        return '倍速 ' + v.playbackRate + '× · 已缓冲 ' + Math.round(seconds) + ' 秒';
      };
    })();
    """
}

struct WebSurface: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

@MainActor
final class BrowserUI: ObservableObject {
    @Published var filterPanel = false
    @Published var privacyPanel = false
    @Published var videoPanel = false
    @Published var confirmClear = false
}

struct BrowserView: View {
    @StateObject private var browser = Browser()
    @StateObject private var ui = BrowserUI()
    @FocusState private var editing: Bool
    @Environment(\.scenePhase) private var scenePhase
    private let accent = Color(red: 0.55, green: 0.95, blue: 0.78)

    var body: some View {
        ZStack {
            Color(red: 0.045, green: 0.06, blue: 0.075).ignoresSafeArea()
            VStack(spacing: 0) {
                HStack {
                    Image(systemName: "shield.lefthalf.filled").foregroundStyle(accent)
                    Text("VEIL").font(.system(.headline, design: .rounded)).tracking(3)
                    Spacer()
                    Button { ui.filterPanel = true } label: { Image(systemName: "shield.checkered") }.accessibilityLabel("广告过滤设置")
                    Text("始终无痕").font(.caption).foregroundStyle(accent)
                    Circle().fill(accent).frame(width: 6, height: 6)
                    Button { ui.privacyPanel = true } label: {
                        Image(systemName: "info.circle").padding(.leading, 8)
                    }.accessibilityLabel("隐私说明")
                }.padding()
                ZStack {
                    if let webView = browser.webView, !browser.isHome {
                        WebSurface(webView: webView).id(ObjectIdentifier(webView))
                    } else {
                        home
                    }
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
                if let error = browser.error {
                    HStack { Text(error).font(.caption); Spacer(); Button("关闭") { browser.error = nil } }.padding().background(.red.opacity(0.15))
                }
                if browser.loading { ProgressView(value: browser.progress).tint(accent) }
                VStack(spacing: 14) {
                    if !browser.isHome { searchBar(prominent: false) }
                    HStack {
                        Button { browser.webView?.goBack() } label: { Image(systemName: "chevron.left") }.disabled(browser.isHome || browser.webView?.canGoBack != true)
                        Spacer()
                        Button { browser.webView?.goForward() } label: { Image(systemName: "chevron.right") }.disabled(browser.isHome || browser.webView?.canGoForward != true)
                        Spacer()
                        Button { if browser.loading { browser.webView?.stopLoading() } else { browser.webView?.reload() } } label: { Image(systemName: browser.loading ? "xmark" : "arrow.clockwise") }.disabled(browser.isHome)
                        Spacer()
                        Button { ui.videoPanel = true } label: { Image(systemName: "play.rectangle") }
                        Spacer()
                        Button { ui.confirmClear = true } label: { Image(systemName: "flame") }.accessibilityLabel("销毁当前会话")
                    }.font(.title3).padding(.horizontal, 8)
                }.padding().background(Color(red: 0.065, green: 0.085, blue: 0.10))
            }
            if scenePhase != .active {
                Color(red: 0.045, green: 0.06, blue: 0.075).ignoresSafeArea()
                Label("VEIL · 隐私保护中", systemImage: "lock.shield").foregroundStyle(accent).font(.title2)
            }
        }
        .foregroundStyle(.white).preferredColorScheme(.dark)
        .task { browser.prepareFilter() }
        .confirmationDialog("销毁所有网页、Cookie 和当前会话？", isPresented: $ui.confirmClear, titleVisibility: .visible) {
            Button("销毁并开始新会话", role: .destructive) { browser.newSession() }
        }
        .sheet(isPresented: $ui.filterPanel) { FilterSettingsView(filter: browser.filtering) }
        .sheet(isPresented: $ui.privacyPanel) { PrivacyInfoView() }
        .sheet(isPresented: $ui.videoPanel) {
            VStack(alignment: .leading, spacing: 24) {
                HStack { Text("视频播放").font(.title2.bold()); Spacer(); Button("完成") { ui.videoPanel = false } }
                Text(browser.videoInfo).foregroundStyle(.secondary)
                Button { browser.video("buffer") } label: { Label("预缓冲当前视频", systemImage: "arrow.down.circle") }
                Button { browser.video("speed") } label: { Label("切换倍速 · 1 / 1.25 / 1.5 / 2", systemImage: "speedometer") }
                Button { browser.video("pip") } label: { Label("画中画", systemImage: "pip.enter") }
                Text("缓冲仅用于本次会话。实际缓冲量由网站与 iOS 决定；跨域嵌入视频可使用网页自身控件。").font(.footnote).foregroundStyle(.secondary)
            }.padding(24).presentationDetents([.medium]).onAppear { browser.video("status") }
        }
    }

    private func searchBar(prominent: Bool) -> some View {
        HStack(spacing: 12) {
            Image(systemName: prominent ? "magnifyingglass" : "lock.shield")
                .foregroundStyle(accent)
            TextField("搜索 Yandex 或输入网址", text: $browser.address)
                .font(.system(size: prominent ? 18 : 16))
                .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.webSearch)
                .submitLabel(.go).focused($editing)
                .onSubmit { browser.open(); editing = false }
                .privacySensitive()
                .accessibilityIdentifier(prominent ? "homeSearchField" : "addressField")
            Button { browser.open(); editing = false } label: {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: prominent ? 32 : 25)).foregroundStyle(accent)
            }
            .accessibilityLabel("搜索或前往网址")
            .disabled(!browser.ready)
        }
        .padding(prominent ? 20 : 14)
        .background(accent.opacity(prominent ? 0.10 : 0.04), in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(accent.opacity(prominent ? 0.65 : 0.15), lineWidth: 1))
        .shadow(color: accent.opacity(prominent ? 0.12 : 0), radius: 20, y: 6)
    }

    private var home: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 0) {
                    Spacer(minLength: 20)
                    VStack(spacing: 22) {
                        Image(systemName: "circle.hexagongrid.fill")
                            .font(.system(size: 44)).foregroundStyle(accent)
                        Text("自由探索，不留足迹。")
                            .font(.system(size: 26, weight: .semibold, design: .rounded))
                            .multilineTextAlignment(.center)
                        searchBar(prominent: true)
                        Text("搜索由 Yandex 提供")
                            .font(.subheadline).foregroundStyle(.secondary)
                        HStack(spacing: 10) {
                            badge(browser.ready ? "广告过滤已开启" : "过滤器准备中", "shield.checkered")
                            badge("不存历史", "eye.slash")
                        }
                        if !browser.ready {
                            if browser.error == nil {
                                ProgressView("正在准备广告过滤器…").font(.footnote)
                            } else {
                                Button("重新加载广告过滤器") { browser.prepareFilter() }
                                    .font(.subheadline).foregroundStyle(accent)
                            }
                        }
                    }.frame(maxWidth: 560)
                    Spacer(minLength: 20)
                }
                .frame(maxWidth: .infinity)
                .frame(minHeight: max(0, geometry.size.height))
                .padding(.horizontal, 24)
            }.scrollDismissesKeyboard(.interactively)
        }
        .overlay(alignment: .bottom) {
            if !editing {
                Text("本机不保存浏览记录 · 关闭后不恢复网页")
                    .font(.caption2).foregroundStyle(.secondary).padding(.bottom, 8)
                    .allowsHitTesting(false)
            }
        }
    }
    private func badge(_ title: String, _ icon: String) -> some View {
        Label(title, systemImage: icon).font(.caption).padding(10).background(accent.opacity(0.08), in: Capsule()).foregroundStyle(accent)
    }
}


struct PrivacyInfoView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    section("始终无痕", "网页使用临时网站数据存储。应用不创建浏览历史数据库，也不在下次启动时恢复上次打开的页面。")
                    section("会话内的数据", "网站运行时仍会临时保留 Cookie、网站状态、视频缓冲和前进/后退记录。点击底部火焰按钮并确认，即可销毁当前会话。")
                    section("规则与更新", "应用内置 AdGuard 规则，每天启动后检查一次更新，也可在广告过滤设置中手动更新。更新直接请求 filters.adtidy.org，不发送浏览网址和搜索词。规则及编译索引缓存在本机，不包含浏览记录；更新失败保留原规则。高级过滤仅使用随应用提供的 Scriptlets 与扩展 CSS，不执行规则中的任意 JavaScript。")
                    section("搜索与网站", "搜索词会发送至 Yandex；访问网页会向对应网站请求内容。网站、搜索服务和网络运营方仍可能获知 IP 地址及访问请求。无痕不等于匿名，清理本机数据不会删除第三方已接收的信息。")
                    section("开发者数据收集", "当前版本未接入开发者运营的数据服务器、账户系统、广告 SDK 或分析 SDK。")
                    section("广告与视频", "广告过滤在设备上进行，不能保证去除所有广告。视频缓冲用于本次会话，不提供离线视频下载。")
                }.frame(maxWidth: 640, alignment: .leading).padding(24)
            }
            .navigationTitle("隐私说明")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
        }.preferredColorScheme(.dark)
    }

    private func section(_ title: String, _ text: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.headline)
            Text(text).font(.subheadline).foregroundStyle(.secondary)
        }
    }
}
