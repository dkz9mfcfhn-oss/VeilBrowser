// SPDX-License-Identifier: GPL-3.0-only
import Foundation
import WebKit
import CryptoKit
import ContentBlockerConverter
import FilterEngine
import SwiftUI

struct FilterSnapshot: Codable, Sendable {
    var json: String
    var advanced: String
    var count: Int
    var advancedCount: Int
    var unsupported: Int
    var updated: Date
    var identifier: String {
        "Veil-AdGuard-4.3.1-" + SHA256.hash(data: Data((json + advanced).utf8)).map { String(format: "%02x", $0) }.joined()
    }
}

/// Serializes the official converter and advanced engine away from the UI thread.
actor FilterWorker {
    static let shared = FilterWorker()
    static let filterIDs = [2, 11, 224, 1, 19, 20]
    private var engines: [String: WebExtension] = [:]
    private let root = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("AdGuardRules", isDirectory: true)
    private var snapshotURL: URL { root.appendingPathComponent("snapshot.json") }

    func load() throws -> FilterSnapshot {
        if let data = try? Data(contentsOf: snapshotURL), data.count < 60_000_000,
           let saved = try? JSONDecoder().decode(FilterSnapshot.self, from: data) { return saved }
        return try bundled()
    }

    func bundled() throws -> FilterSnapshot {
        guard let folder = Bundle.main.url(forResource: "FilterResources", withExtension: nil) else { throw FilterFailure.resources }
        let json = try String(contentsOf: folder.appendingPathComponent("rules.json"), encoding: .utf8)
        let advanced = try String(contentsOf: folder.appendingPathComponent("advanced.txt"), encoding: .utf8)
        let meta = try JSONSerialization.jsonObject(with: Data(contentsOf: folder.appendingPathComponent("manifest.json"))) as? [String: Any]
        return FilterSnapshot(json: json, advanced: advanced,
                              count: meta?["safariRulesCount"] as? Int ?? 0,
                              advancedCount: meta?["advancedRulesCount"] as? Int ?? 0,
                              unsupported: meta?["errorsCount"] as? Int ?? 0,
                              updated: ISO8601DateFormatter().date(from: (meta?["updated"] as? String ?? "2026-10-18") + "T02:00:00Z") ?? Date(timeIntervalSince1970: 0))
    }

    func buildAdvanced(_ snapshot: FilterSnapshot) throws {
        let key = snapshot.identifier
        if engines[key] != nil { return }
        let engine = try WebExtension(containerURL: root.appendingPathComponent(key), version: .safari16_4)
        let meta = root.appendingPathComponent(key).appendingPathComponent(Schema.BASE_DIR).appendingPathComponent(Schema.ENGINE_META_FILE_NAME)
        if !FileManager.default.fileExists(atPath: meta.path) || engine.lookup(pageUrl: URL(string: "https://filter-health.invalid")!, topUrl: nil) == nil { _ = try engine.buildFilterEngine(rules: snapshot.advanced) }
        engines[key] = engine
    }

    func configuration(for url: URL, top: URL?, identifier: String, pageWorld: Bool) -> [String: Any] {
        guard let c = engines[identifier]?.lookup(pageUrl: url, topUrl: top) else { return [:] }
        // Raw JavaScript from downloaded filters is deliberately never executed.
        // Scriptlet implementations are fixed, reviewed assets shipped in the app.
        if pageWorld { return ["scriptlets": c.scriptlets.map { ["name": $0.name, "args": $0.args] as [String: Any] }] }
        return ["css": c.css, "extendedCss": c.extendedCss]
    }

    func shouldCheck() -> Bool {
        let file = root.appendingPathComponent("lastCheck.txt")
        let last = (try? String(contentsOf: file, encoding: .utf8)).flatMap(TimeInterval.init) ?? 0
        guard Date().timeIntervalSince1970 - last > 86_400 else { return false }
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try? String(Date().timeIntervalSince1970).write(to: file, atomically: true, encoding: .utf8)
        return true
    }

    func download() async throws -> FilterSnapshot {
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieStorage = nil; config.urlCache = nil
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.timeoutIntervalForRequest = 25; config.timeoutIntervalForResource = 45
        let session = URLSession(configuration: config, delegate: FilterHTTPSDelegate(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        var texts: [Int: String] = [:]
        // Stream each response with a size ceiling, including before decoding.
        for id in Self.filterIDs {
            let url = URL(string: "https://filters.adtidy.org/ios/filters/\(id)_optimized.txt")!
            let (bytes, response) = try await session.bytes(from: url)
            #if DEBUG
            print("[FilterDownload] id=\(id), status=\((response as? HTTPURLResponse)?.statusCode ?? -1), expected=\(response.expectedContentLength)")
            #endif
            guard let response = response as? HTTPURLResponse, response.statusCode == 200,
                  response.expectedContentLength <= 8_000_000 else { throw FilterFailure.download }
            var data = Data()
            for try await byte in bytes {
                if data.count >= 8_000_000 { throw FilterFailure.download }
                data.append(byte)
            }
            #if DEBUG
            print("[FilterDownload] id=\(id), bytes=\(data.count)")
            #endif
            guard let text = String(data: data, encoding: .utf8), text.contains("! Title:"),
                  text.contains("AdGuard"), text.split(whereSeparator: \.isNewline).count > 100 else { throw FilterFailure.download }
            texts[id] = text
        }
        var seen = Set<String>()
        let lines = Self.filterIDs.flatMap { (texts[$0] ?? "").split(whereSeparator: \.isNewline).map(String.init) }
            .filter { !$0.hasPrefix("!") && !$0.isEmpty && seen.insert($0).inserted }
        let result = ContentBlockerConverter().convertArray(rules: lines, safariVersion: .safari16_4, advancedBlocking: true)
        guard result.safariRulesCount > 20_000, result.discardedSafariRules == 0,
              result.safariRulesJSON.utf8.count < 35_000_000 else { throw FilterFailure.conversion }
        return FilterSnapshot(json: result.safariRulesJSON, advanced: result.advancedRulesText ?? "",
                              count: result.safariRulesCount, advancedCount: result.advancedRulesCount,
                              unsupported: result.errorsCount, updated: Date())
    }

    func save(_ snapshot: FilterSnapshot) throws {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try JSONEncoder().encode(snapshot).write(to: snapshotURL, options: .atomic)

    }
}

private final class FilterHTTPSDelegate: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(request.url?.scheme == "https" && request.url?.host == "filters.adtidy.org" ? request : nil)
    }
}

enum FilterFailure: LocalizedError {
    case resources, download, conversion
    var errorDescription: String? {
        switch self {
        case .resources: return "内置过滤规则缺失"
        case .download: return "规则下载失败或文件无效，原规则继续保护"
        case .conversion: return "新规则未通过兼容检查，原规则继续保护"
        }
    }
}

@MainActor
final class AdFilterController: ObservableObject {
    @Published var updating = false
    @Published var status = "正在准备增强过滤"
    @Published var count = 0
    @Published var advancedCount = 0
    @Published var unsupported = 0
    @Published var updated: Date?
    @Published var failure: String?
    private(set) var identifier = ""
    private(set) var compiled: WKContentRuleList?
    var onChange: (() -> Void)?
    private var prepared = false
    private var preparing: Task<Void, Error>?

    func prepare() async throws {
        if prepared { return }
        if let preparing { return try await preparing.value }
        let task = Task { @MainActor in
            var snapshot = try await FilterWorker.shared.load()
            let list: WKContentRuleList
            do { list = try await Self.compile(snapshot) }
            catch {
                snapshot = try await FilterWorker.shared.bundled()
                list = try await Self.compile(snapshot)
                failure = "更新缓存不可用，已恢复内置规则"
            }
            try await FilterWorker.shared.buildAdvanced(snapshot)
            install(snapshot, list: list)
            prepared = true
            Task { @MainActor in
                if await FilterWorker.shared.shouldCheck() { await update() }
            }
        }
        preparing = task
        do { try await task.value; preparing = nil } catch { preparing = nil; throw error }
    }

    private static func compile(_ snapshot: FilterSnapshot) async throws -> WKContentRuleList {
        let store = WKContentRuleListStore.default()!
        let identifier = snapshot.identifier
        let cached: WKContentRuleList? = await withCheckedContinuation { continuation in
            store.lookUpContentRuleList(forIdentifier: identifier) { list, _ in continuation.resume(returning: list) }
        }
        if let cached { return cached }
        return try await withCheckedThrowingContinuation { continuation in
            store.compileContentRuleList(forIdentifier: identifier, encodedContentRuleList: snapshot.json) { list, error in
                if let list { continuation.resume(returning: list) }
                else { continuation.resume(throwing: error ?? FilterFailure.conversion) }
            }
        }
    }

    private func install(_ snapshot: FilterSnapshot, list: WKContentRuleList) {
        compiled = list; identifier = snapshot.identifier
        count = snapshot.count; advancedCount = snapshot.advancedCount
        unsupported = snapshot.unsupported; updated = snapshot.updated
        status = "增强过滤已开启"
        onChange?()
    }

    func update() async {
        guard prepared, !updating else { return }
        updating = true; failure = nil
        defer { updating = false }
        do {
            let snapshot = try await FilterWorker.shared.download()
            let list = try await Self.compile(snapshot)
            try await FilterWorker.shared.buildAdvanced(snapshot)
            try await FilterWorker.shared.save(snapshot)
            install(snapshot, list: list)
            status = "已更新，重新打开网页后完整生效"
        } catch { failure = "更新未完成，原规则继续保护。\(error.localizedDescription)" }
    }

    func attach(to controller: WKUserContentController) {
        if let compiled { controller.add(compiled) }
        let handler = FilterPageBridge(filter: self)
        controller.addScriptMessageHandler(handler, contentWorld: .page, name: "veilFilterConfig")
        controller.addScriptMessageHandler(handler, contentWorld: .defaultClient, name: "veilFilterConfig")
        for (name, world) in [("page-filter", WKContentWorld.page), ("cosmetic-filter", WKContentWorld.defaultClient)] {
            if let folder = Bundle.main.url(forResource: "FilterResources", withExtension: nil),
               let source = try? String(contentsOf: folder.appendingPathComponent(name + ".js"), encoding: .utf8) {
                controller.addUserScript(WKUserScript(source: source, injectionTime: .atDocumentStart, forMainFrameOnly: false, in: world))
            }
        }
    }
}

@MainActor
private final class FilterPageBridge: NSObject, WKScriptMessageHandlerWithReply {
    weak var filter: AdFilterController?
    init(filter: AdFilterController) { self.filter = filter }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage,
                               replyHandler: @escaping (Any?, String?) -> Void) {
        guard let filter, let url = message.frameInfo.request.url,
              ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { replyHandler([:], nil); return }
        let key = filter.identifier
        let top = message.frameInfo.isMainFrame ? nil : message.webView?.url
        let pageWorld = (message.body as? String) == "page"
        Task {
            let config = await FilterWorker.shared.configuration(for: url, top: top, identifier: key, pageWorld: pageWorld)
            replyHandler(config, nil)
        }
    }
}

struct FilterSettingsView: View {
    @ObservedObject var filter: AdFilterController
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Label(filter.status, systemImage: "shield.checkered")
                    LabeledContent("WebKit 规则", value: filter.count.formatted())
                    LabeledContent("高级规则", value: filter.advancedCount.formatted())
                    if let date = filter.updated { LabeledContent("规则版本日期", value: date.formatted(date: .numeric, time: .omitted)) }
                    if filter.unsupported > 0 { Text("\(filter.unsupported) 条规则不兼容，已跳过").font(.footnote).foregroundStyle(.secondary) }
                }
                Section("已启用规则") {
                    Text("AdGuard 基础、中文、移动广告、俄语、弹窗、App 推广规则")
                    Text("同时保留隐幕对底部安装推广条的补充保护。普通搜索结果链接可在当前页面打开。").font(.footnote).foregroundStyle(.secondary)
                }
                Section {
                    Button { Task { await filter.update() } } label: {
                        HStack { Text(filter.updating ? "正在更新…" : "立即更新规则"); if filter.updating { Spacer(); ProgressView() } }
                    }.disabled(filter.updating || filter.count == 0)
                    Text("启动后每天自动检查一次。更新失败时保留原规则，不发送浏览网址或搜索词。").font(.footnote).foregroundStyle(.secondary)
                    if let error = filter.failure { Text(error).font(.footnote).foregroundStyle(.orange) }
                }
                Section("覆盖范围") {
                    Text("支持网络拦截、页面隐藏、扩展 CSS 和内置 Scriptlets。规则中的任意 JavaScript 不执行。受 WebKit 限制，不能承诺过滤全部视频内嵌广告，也不等同于 AdGuard 所有平台的完整能力。").font(.footnote)
                    NavigationLink("规则来源与开源许可") {
                        ScrollView { Text((Bundle.main.url(forResource: "FilterResources", withExtension: nil).flatMap { try? String(contentsOf: $0.appendingPathComponent("NOTICES.txt"), encoding: .utf8) }) ?? "见工程 Vendor 与 FilterSources")
                            .font(.caption.monospaced()).textSelection(.enabled).padding() }.navigationTitle("来源与许可")
                    }
                }
            }.navigationTitle("广告过滤").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
        }.preferredColorScheme(.dark)
    }
}
