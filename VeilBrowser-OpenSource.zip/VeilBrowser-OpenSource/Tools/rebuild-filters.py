#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Rebuild bundled data with the pinned official converter; no browsing data is read."""
from pathlib import Path
import argparse, hashlib, json, subprocess, datetime
root = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--converter', required=True, help='Official SafariConverterLib 4.3.1 ConverterTool path, with its PSL resource bundle')
args = p.parse_args()
ids = [2, 11, 224, 1, 19, 20]
source = root / 'FilterSources'
combined = source / 'combined.txt'
seen = set()
lines = []
for i in ids:
    for line in (source / f'{i}.txt').read_text().splitlines():
        if line and not line.startswith('!') and line not in seen:
            seen.add(line)
            lines.append(line)
combined.write_text('\n'.join(lines))
result = subprocess.run([str(Path(args.converter).resolve()), 'convert', '--safari-version', '16.4', '--advanced-blocking', 'true', '--input-path', str(combined)], check=True, capture_output=True, text=True)
data = json.loads(result.stdout)
assert data['discardedSafariRules'] == 0 and data['safariRulesCount'] > 20000
res = root / 'VeilBrowser' / 'FilterResources'
(res / 'rules.json').write_text(data['safariRulesJSON'])
(res / 'advanced.txt').write_text(data.get('advancedRulesText', ''))
meta = {k: v for k, v in data.items() if k not in ['safariRulesJSON', 'advancedRulesText']}
meta.update(updated=datetime.datetime.now(datetime.timezone.utc).date().isoformat(), converter='4.3.1', sha256=hashlib.sha256(data['safariRulesJSON'].encode()).hexdigest())
(res / 'manifest.json').write_text(json.dumps(meta))
print(json.dumps(meta, indent=2))
