# SPDX-License-Identifier: GPL-3.0-only
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1];res=r/'VeilBrowser/FilterResources'
core=json.loads((r/'Vendor/scriptlets/dist/scriptlets.corelibs.json').read_text())
page='''/* AdGuard Scriptlets 2.3.1, GPL-3.0; see NOTICES.txt. */\n(()=>{\nconst registry=Object.create(null);\n'''
for item in core['scriptlets']:
 page+='{const fn='+item['scriptlet']+';for(const name of '+json.dumps(item['names'])+')registry[name]=fn;}\n'
page+='''
const bridge=window.webkit?.messageHandlers?.veilFilterConfig;
if(!bridge)return;
bridge.postMessage('page').then(conf=>{
 for(const s of conf.scriptlets||[]){
  const fn=registry[s.name]; if(!fn)continue;
  try{fn({name:s.name,args:s.args,engine:'corelibs',uniqueId:'veil',verbose:false},s.args);}catch(_){}
 }
}).catch(()=>{});
})();
'''
(res/'page-filter.js').write_text(page)
css='''/* AdGuard ExtendedCss 2.1.1, GPL-3.0; see NOTICES.txt. */\n(()=>{\n'''+(r/'Vendor/extended-css/dist/extended-css.min.js').read_text()+'''
const bridge=window.webkit?.messageHandlers?.veilFilterConfig;
if(!bridge)return;
const toRules=items=>(items||[]).map(s=>s.trim()).filter(Boolean).map(s=>s.endsWith('}')?s:s+'{display:none!important;}');
bridge.postMessage('cosmetic').then(conf=>{
 const css=toRules(conf.css).join('\\n');
 if(css){
  const style=document.createElement('style');
  const ensure=()=>{if(style.textContent!==css)style.textContent=css;if(document.documentElement&&!style.isConnected)document.documentElement.append(style);};
  ensure();new MutationObserver(ensure).observe(document,{childList:true,subtree:true,characterData:true});
 }
 const rules=toRules(conf.extendedCss);
 if(rules.length){try{const engine=new ExtendedCss({cssRules:rules});engine.apply();}catch(_){}}
}).catch(()=>{});
})();
'''
(res/'cosmetic-filter.js').write_text(css)
