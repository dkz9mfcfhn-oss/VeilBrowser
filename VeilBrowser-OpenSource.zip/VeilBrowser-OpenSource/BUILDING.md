# Build and corresponding source

This source corresponds to VeilBrowser 1.3 (build 6). The original functional version was built and tested with Xcode 27.1 and an iPhone 18 Pro / iOS 27 simulator. Deployment target is iOS 17; iOS 17 runtime compatibility has not been independently tested.

Open VeilBrowser.xcodeproj and select the VeilBrowser scheme. The application uses the local Vendor Swift package, so its Swift dependencies do not require remote package resolution. Bundled filter JSON, advanced-rule text, static JS assets, original filter snapshots, and preferred upstream source are provided.

For the simulator, select an iPhone simulator and Run. For a physical iPhone, choose your own Apple development team, set a unique bundle identifier if necessary, connect and trust the device, and enable Developer Mode as instructed by Xcode. No private signing key, provisioning profile, user subscription, or developer account credential is included or required from the original developer. App Store signing and distribution require appropriate permissions and the separate license review described in APPSTORE-PERMISSION-PENDING.md.

Unsigned SDK build example:

```sh
xcodebuild -project VeilBrowser.xcodeproj -scheme VeilBrowser -configuration Release -sdk iphoneos -derivedDataPath ./Build CODE_SIGNING_ALLOWED=NO build
```

Rebuild filter data with Tools/rebuild-filters.py and the pinned official ConverterTool, as detailed in Tools/README.md. Rebuild static script assets with `python3 Tools/build-runtime-assets.py`. The upstream preferred sources and their lockfiles are included if rebuilding the upstream JS libraries is required; follow their supplied development instructions for those builds. No dynamic downloaded JavaScript is executed by this application.

Rule files and indexes in app caches are public filtering data, not browser history. To recreate a clean source build, use the bundled resources; do not copy any runtime Keychain, simulator data container, signing identity, or browser session from another device.
