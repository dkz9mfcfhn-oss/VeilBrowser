# VeilBrowser / 隐幕

Open-source iOS private browser. Original application code is GPL-3.0-only; see LICENSE and COPYING. Third-party notices: THIRD_PARTY.md. Build and regeneration instructions: BUILDING.md and Tools/README.md.

Repository: https://github.com/dkz9mfcfhn-oss/VeilBrowser

AdGuard components remain included. App Store binary distribution permission is pending; see APPSTORE-PERMISSION-PENDING.md. The source release does not claim that an App Store exception has been obtained. Personal signing configuration and account data are excluded.

# 隐幕 · Veil Browser

原生 SwiftUI + WKWebView 浏览器，最低 iOS 17，支持 iPhone 和 iPad。

## 功能

- 首页中央显示加大的搜索框，固定使用 `https://yandex.tm/search/` 的 Yandex，没有切换搜索引擎的设置；也可以直接输入网址。
- 启动即使用 `WKWebsiteDataStore.nonPersistent()`。不创建浏览历史数据库、不恢复上次页面、不接入统计 SDK。
- 当前会话可前进、后退；点击火焰按钮可销毁网页与临时网站数据，创建全新的无痕会话。
- 广告过滤规则完成编译后才允许加载网站。内置常见广告域名、Yandex 广告域名及页面广告容器规则。
- 阻止脚本新窗口和 JavaScript 弹窗；普通点击触发的 target=_blank 链接改在当前无痕页面打开，已识别广告链接仍被阻止。
- 按明确广告标记隐藏常见悬浮、吸底、遮屏广告，包括稍后动态插入的匹配元素。保留未标记为广告的普通对话框、固定导航和视频播放器。
- 页内视频、画中画、1 / 1.25 / 1.5 / 2 倍速，播放时启用当前视频预缓冲，可查询已缓冲秒数。
- 后台及任务切换时使用隐私遮罩。

## 针对反馈页面的广告修复

反馈页面使用站内 `/traffic/go` 签名跳转，而不是通用广告类名。现在对确认的网站增加独立的网络拦截与横幅容器隐藏规则，并在导航代理里识别跳转参数中 `kind=ad` 的广告链接。

新增隔离脚本监听后续插入或修改的广告链接。只有明确标记为广告的链接才会被清理；包含视频、表单或普通链接的父容器不会因这条规则被整体隐藏。

在原运行页面应用相同隐藏选择器的诊断结果：30 个广告入口从可见变为隐藏，播放器节点仍保留。后续复现并定位到底部浮层：生成的 H5 `swipercontainer` 容器同时包含 `iframeid` 广告帧和 `alabelbox` 标记。现在加入按结构识别的独立规则，不依赖随机数字后缀。原页面验证命中 1 个浮层，可见数量从 1 变为 0；模拟动态插入同结构广告也被隐藏，普通播放器 iframe 数量维持 1，视频继续播放。不同广告结构仍需根据复现情况补充规则。

本次另已验证广告重定向识别、无效参数和普通网址不误拦截，以及 Debug 编译。

## 启动优化

- 首页不再创建 WKWebView；第一次搜索或访问网址时才初始化网页内核。
- 优先异步读取已编译的广告规则缓存，仅在缓存缺失或不兼容时编译；缓存标识由规则内容的 SHA-256 生成，规则变化自动失效。
- 重复显示首页或销毁会话不会重复编译规则，也不会清空正在输入的搜索内容。
- 缓存仅包含静态拦截规则，网页仍使用临时数据存储；第一条网络请求前必须安装过滤规则。
- Debug 构建提供不含网址或搜索词的初始化计时日志；Release 不输出这些日志。

加入代理功能前的 iPhone 18 Pro / iOS 27.0 模拟器 Debug 检查：规则缓存命中到就绪约 214ms，首页没有创建网页内核；首次打开网址时内核初始化约 211ms。实际网页加载已验证，销毁会话后正确返回空白首页并保持过滤开启。以上是组件计时，不是从点击 App 图标到首屏的完整启动时间，也没有真机前后对比数据。Debug 与 Release 的 iPhoneOS 编译均已通过。

## 应用图标

采用用户选定的浅色背景、深灰折叠帷幕图案，保留原图样式。1024×1024 图标已加入 `Assets.xcassets/AppIcon.appiconset` 并配置为 AppIcon；图标资源编译和 CFBundleIcons 检查通过。

## 在 iPhone 上运行

1. 用 Xcode 打开 `VeilBrowser.xcodeproj`。
2. 在 Target → Signing & Capabilities 选择你的 Apple 开发团队；必要时将 Bundle Identifier 改成自己的唯一标识。
3. 连接 iPhone、开启开发者模式，选择设备后点击 Run。

本项目未包含开发者签名，不能直接作为已签名 IPA 安装，也没有发布到 App Store。

## 验证结果

已通过本机 Xcode 27.1 的 iPhoneOS arm64 Debug 编译（关闭代码签名）。搜索编码、网址分流和广告规则匹配另有本地检查。
已通过 Xcode 重新运行 iPhone 18 Pro / iOS 27.0 模拟器，确认首页搜索框居中、过滤器编译成功并显示“广告过滤已开启”。真机后台遮罩和不同视频网站的播放表现仍需真机验证。

已修复原广告过滤器的加载失败：WebKit 不支持规则中的正则“或”表达式（`a|b`），现改为每个域名独立生成规则，并新增失败重试入口。

## 边界

无痕是本机不持久保存浏览数据，不代表匿名网络：网站、Yandex 和网络运营方仍可能获知访问情况。运行中的会话为保持网页功能，临时保留 Cookie 和返回栈；销毁会话或进程结束后不恢复。

内置的是基础广告过滤规则，不能保证去除全部广告，尤其是与视频内容使用同一来源的片头广告；部分网站可能因为拦截而无法正常使用。

视频预缓冲通过 HTML 视频 preload 提示 WebKit，不能强制指定缓冲大小，不支持离线下载或 DRM 绕过。当前视频可以尽量提前缓冲，但实际下载范围由 iOS 和网站控制。跨域 iframe、Shadow DOM 或自定义播放器的倍速/画中画按钮不保证可控制，请使用网页自身的播放器。

## 参考

- Apple 临时网站数据存储：https://developer.apple.com/documentation/webkit/wkwebsitedatastore
- Yandex 搜索地址：https://yandex.com/support/common/en/browsers-settings/yandex-searches

## 2026-10-18 浮层广告复测与加固

- 在文档开始加载时注入隔离样式，减少广告露出的时间，样式被删除后会补回。
- 监听已识别广告的样式改写，广告脚本恢复 display 时会再次隐藏；不因普通视频动画的样式更新而扫描整个页面。
- 隐藏操作只在样式实际变化时写入，避免观察器自触发循环。
- 规则缓存按内容生成标识，避免新规则复用旧缓存。
- 最终版已在模拟器重新安装并打开原页验证：实际浮层匹配 1 个，可见 0 个；动态插入后隐藏、强制改回可见后再次隐藏均通过，普通轮播容器及播放器 iframe 保留。
- 诊断用的页面结构日志已移除；公开版本不记录这些调试信息。

## 1.2（3）更新

- 删除代理页面、订阅、测速、内核和依赖，升级时清除旧订阅钥匙串条目。
- 默认搜索入口改为 https://yandex.tm/search/。
- 扩大底部广告容器结构识别；全部明确广告选择器持续强制隐藏。修复动态插入、样式恢复及样式表被篡改后的保护。
- 拦截脚本新窗口及 JavaScript 弹窗；1.2（4）修复普通搜索结果链接被误拦截的问题。
- 后续已针对当前实际反馈页面复测，见 1.2（5）；本地样例不能证明所有真实网站广告都被移除。

本版已通过 Xcode 的 iPhone 18 Pro / iOS 27 模拟器构建及 8 项实际 WKWebView 回归：嵌套底部浮层、动态插入、强制恢复显示、广告属性动态添加、样式表篡改、样式表删除均被处理，普通视频、iframe、底部导航、轮播保留。回归使用与正式版相同的隔离脚本及内容规则。测试钩子已移除。以上为 1.2（3）的样例验证；1.2（5）已在模拟器复测最新反馈页面，用户手机仍待验证。

1.2（4）交互回归：模拟器真实点击已知广告链接和脚本弹窗均停留原页；普通 target=_blank 链接成功转入当前页面。修复了上一版拦截所有新窗口造成搜索结果点击无效的问题。

## 1.2（5）底部安装推广条

实际反馈页面的推广条是无 id、无 class 的 fixed div，内部两个 span，文案为“防失联,请点击这里安装APP”。新增文案、固定底部位置、尺寸的联合判断，隐藏整个小型推广层；不按“中文”或“底部”单独过滤。排除包含视频、音频、表单、输入框或编辑区域的容器。支持匿名容器重复插入、文本改变和恢复显示；监听提前至文档开始时安装。

原页面实测：命中 1 个匿名底部安装推广层，可见数量为 0；顶部导航仍显示，原有 31 个视频节点保留。该结果针对这条中文安装推广浮层，不表示页面全部广告或所有其他网站广告均被清除。

新增推广层相关 4 项与之前 8 项、共 12 项 WKWebView 回归通过：重复创建、强制恢复仍隐藏，普通中文消息及正文、播放器、普通导航保留。临时自动打开页面与结构诊断代码已移除。

## AdGuard 规则升级

版本 1.3（6）接入官方转换器、中文等六组规则、ExtendedCss 和 Scriptlets；详细数量、验证、更新与许可说明见 [过滤升级说明](过滤升级说明.md)，重建方法见 Tools/README.md。新增顶部盾牌入口查看和更新规则。
