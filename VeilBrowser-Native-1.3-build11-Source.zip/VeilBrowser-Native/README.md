# 隐幕 App Store source — 1.3 build 11

This independent distribution project contains only project-owned application code and artwork. It does not link SafariConverterLib, FilterEngine, Scriptlets, ExtendedCss, Punycode or swift-psl; it contains no imported third-party filter lists, generated filter resources or subscription updater. Native WebKit rules and independently authored site diagnostics remain. It does not use AdGuard branding.

Project-owned code in this distribution is offered under MIT. Previously published GPL snapshots and third-party licenses remain unchanged; this grant does not relicense third-party material.

Open VeilBrowser.xcodeproj in Xcode. iOS 17+, iPhone and iPad. Bundle ID com.local.VeilBrowser, version 1.3 (11). Select your signing team before distribution. No signing keys included.

Search uses yandex.tm; browsing uses nonpersistent WKWebView data. No history database, analytics SDK, VPN or video downloader. Filter coverage is smaller than the prior engine and must not be represented as equivalent.

Status: not submitted to App Review.
